1. Readme for Template Generation
=================================
   
Step 1: Unzip the archive to a working folder (say c:\asm)

The folder c:\asm will contain the following files:
	
	1. asm-sample.tex (Sample LaTeX File Example)
	2. asm.dtx (a bundle of LaTeX and BibTeX files to produce ASM papers)
	3. asm.ins (This is file `asm.ins', the installation file for t `asm' distribution)
	4. journals_logo_w_asm_logo_stacked.png (ASM Logo)

	Please also add graphics files if any illustrations used in your LaTeX Document file

Step 2: Open Command Prompt and change to c:\asm folder:

       cd c:\asm

Step 3: Run pdflatex on asm.ini file to generate ASM Class file:
       
       c:\asm>c:\texlive\2022\bin\win32\pdflatex.exe asm.ins

       We get the LaTeX class file and .bst file (Bibliography Style file):

       asmarticle.cls
       asm.bst

Step 4: Run asm-sample file to generate Output PDF:

       c:\asm>c:\texlive\2022\bin\win32\pdflatex.exe asm-sample.tex


2. Sample PDF Generation (default)
==================================

Without using any special option in preamble:

\documentclass{asmarticle} 

3. Sample Draft PDF Generation
==============================

Use Draft option in preamble:

Example: \documentclass[draft]{asmarticle} 

4. Sample Double-Blind PDF Generation
=====================================

Use DoubleBlind option in preamble:

Example: \documentclass[DoubleBlind]{asmarticle}

==========================Thank You==============================


